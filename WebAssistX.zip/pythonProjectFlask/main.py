from flask import Flask, render_template, request
import secrets
from gtts import gTTS
import wikipedia

app = Flask(__name__)

def generate_password(length):
    characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    password = ''.join(secrets.choice(characters) for _ in range(length))
    return password

@app.route('/')
def task_selection():
    return render_template('task_selection.html')

@app.route('/generate_password', methods=['POST'])
def generate_password_route():
    length = int(request.form['password_length'])
    password = generate_password(length)
    return render_template('task_selection.html', password=password, task="password")

@app.route('/generate_audio', methods=['POST'])
def generate_audio():
    topic = request.form['audio_topic']
    output_file = request.form['audio_output_file']
    tts = gTTS(topic)
    tts.save(output_file)
    return render_template('task_selection.html', output_file=output_file, task="audio")

@app.route('/generate_introduction', methods=['POST'])
def generate_introduction():
    topic = request.form['introduction_topic']
    summary = wikipedia.summary(topic, sentences=2)
    return render_template('task_selection.html', summary=summary, task="introduction")

if __name__ == '__main__':
    app.run(debug=True)
